#!/usr/bin/env python

import copy
import doctest
import os
import subprocess
import sys
import tempfile
import unittest

import jsonpointer
from jsonpointer import resolve_pointer, EndOfList, JsonPointerException, \
    JsonPointer, set_pointer


class SpecificationTests(unittest.TestCase):
    """ Tests all examples from the JSON Pointer specification """

    def test_example(self):
        doc = {
            "foo": ["bar", "baz"],
            "": 0,
            "a/b": 1,
            "c%d": 2,
            "e^f": 3,
            "g|h": 4,
            "i\\j": 5,
            "k\"l": 6,
            " ": 7,
            "m~n": 8
        }

        self.assertEqual(resolve_pointer(doc, ""), doc)
        self.assertEqual(resolve_pointer(doc, "/foo"), ["bar", "baz"])
        self.assertEqual(resolve_pointer(doc, "/foo/0"), "bar")
        self.assertEqual(resolve_pointer(doc, "/"), 0)
        self.assertEqual(resolve_pointer(doc, "/a~1b"), 1)
        self.assertEqual(resolve_pointer(doc, "/c%d"), 2)
        self.assertEqual(resolve_pointer(doc, "/e^f"), 3)
        self.assertEqual(resolve_pointer(doc, "/g|h"), 4)
        self.assertEqual(resolve_pointer(doc, "/i\\j"), 5)
        self.assertEqual(resolve_pointer(doc, "/k\"l"), 6)
        self.assertEqual(resolve_pointer(doc, "/ "), 7)
        self.assertEqual(resolve_pointer(doc, "/m~0n"), 8)

    def test_eol(self):
        doc = {
            "foo": ["bar", "baz"]
        }

        self.assertTrue(isinstance(resolve_pointer(doc, "/foo/-"), EndOfList))
        self.assertRaises(JsonPointerException, resolve_pointer, doc, "/foo/-/1")

    def test_round_trip(self):
        paths = [
            "",
            "/foo",
            "/foo/0",
            "/",
            "/a~1b",
            "/c%d",
            "/e^f",
            "/g|h",
            "/i\\j",
            "/k\"l",
            "/ ",
            "/m~0n",
            '/\xee',
        ]
        for path in paths:
            ptr = JsonPointer(path)
            self.assertEqual(path, ptr.path)

            parts = ptr.get_parts()
            self.assertEqual(parts, ptr.parts)
            new_ptr = JsonPointer.from_parts(parts)
            self.assertEqual(ptr, new_ptr)

    def test_str_and_repr(self):
        paths = [
            ("", "", "JsonPointer('')"),
            ("/foo", "/foo", "JsonPointer('/foo')"),
            ("/foo/0", "/foo/0", "JsonPointer('/foo/0')"),
            ("/", "/", "JsonPointer('/')"),
            ("/a~1b", "/a~1b", "JsonPointer('/a~1b')"),
            ("/c%d", "/c%d", "JsonPointer('/c%d')"),
            ("/e^f", "/e^f", "JsonPointer('/e^f')"),
            ("/g|h", "/g|h", "JsonPointer('/g|h')"),
            ("/i\\j", "/i\\j", "JsonPointer('/i\\\\j')"),
            ("/k\"l", "/k\"l", "JsonPointer('/k\"l')"),
            ("/ ", "/ ", "JsonPointer('/ ')"),
            ("/m~0n", "/m~0n", "JsonPointer('/m~0n')"),
        ]
        for path, ptr_str, ptr_repr in paths:
            ptr = JsonPointer(path)
            self.assertEqual(path, ptr.path)
            self.assertEqual(ptr_str, str(ptr))
            self.assertEqual(ptr_repr, repr(ptr))

        path = "/\xee"
        ptr_str = "/\xee"
        ptr_repr = "JsonPointer('/\xee')"
        ptr = JsonPointer(path)
        self.assertEqual(path, ptr.path)
        self.assertEqual(ptr_str, str(ptr))
        self.assertEqual(ptr_repr, repr(ptr))

        self.assertIsInstance(str(ptr), str)
        self.assertIsInstance(repr(ptr), str)

    def test_parts(self):
        paths = [
            ("", []),
            ("/foo", ['foo']),
            ("/foo/0", ['foo', '0']),
            ("/", ['']),
            ("/a~1b", ['a/b']),
            ("/c%d", ['c%d']),
            ("/e^f", ['e^f']),
            ("/g|h", ['g|h']),
            ("/i\\j", ['i\\j']),
            ("/k\"l", ['k"l']),
            ("/ ", [' ']),
            ("/m~0n", ['m~n']),
            ('/\xee', ['\xee']),
        ]
        for path in paths:
            ptr = JsonPointer(path[0])
            self.assertEqual(ptr.get_parts(), path[1])


class ComparisonTests(unittest.TestCase):

    def setUp(self):
        self.ptr1 = JsonPointer("/a/b/c")
        self.ptr2 = JsonPointer("/a/b")
        self.ptr3 = JsonPointer("/b/c")

    def test_eq_hash(self):
        p1 = JsonPointer("/something/1/b")
        p2 = JsonPointer("/something/1/b")
        p3 = JsonPointer("/something/1.0/b")

        self.assertEqual(p1, p2)
        self.assertNotEqual(p1, p3)
        self.assertNotEqual(p2, p3)

        self.assertEqual(hash(p1), hash(p2))
        self.assertNotEqual(hash(p1), hash(p3))
        self.assertNotEqual(hash(p2), hash(p3))

        # a pointer compares not-equal to objects of other types
        self.assertFalse(p1 == "/something/1/b")

    def test_contains(self):
        self.assertTrue(self.ptr1.contains(self.ptr2))
        self.assertTrue(self.ptr1.contains(self.ptr1))
        self.assertFalse(self.ptr1.contains(self.ptr3))

    def test_contains_magic(self):
        self.assertTrue(self.ptr2 in self.ptr1)
        self.assertTrue(self.ptr1 in self.ptr1)
        self.assertFalse(self.ptr3 in self.ptr1)

    def test_join(self):
        ptr12a = self.ptr1.join(self.ptr2)
        self.assertEqual(ptr12a.path, "/a/b/c/a/b")

        ptr12b = self.ptr1.join(self.ptr2.parts)
        self.assertEqual(ptr12b.path, "/a/b/c/a/b")

        ptr12c = self.ptr1.join(self.ptr2.parts[0:1])
        self.assertEqual(ptr12c.path, "/a/b/c/a")

        ptr12d = self.ptr1.join("/a/b")
        self.assertEqual(ptr12d.path, "/a/b/c/a/b")

        ptr12e = self.ptr1.join(["a", "b"])
        self.assertEqual(ptr12e.path, "/a/b/c/a/b")

        self.assertRaises(JsonPointerException, self.ptr1.join, 0)

    def test_join_magic(self):
        ptr12a = self.ptr1 / self.ptr2
        self.assertEqual(ptr12a.path, "/a/b/c/a/b")

        ptr12b = self.ptr1 / self.ptr2.parts
        self.assertEqual(ptr12b.path, "/a/b/c/a/b")

        ptr12c = self.ptr1 / self.ptr2.parts[0:1]
        self.assertEqual(ptr12c.path, "/a/b/c/a")

        ptr12d = self.ptr1 / "/a/b"
        self.assertEqual(ptr12d.path, "/a/b/c/a/b")

        ptr12e = self.ptr1 / ["a", "b"]
        self.assertEqual(ptr12e.path, "/a/b/c/a/b")

    def test_join_subclass(self):
        class Pointer(JsonPointer):
            pass

        class OtherPointer(JsonPointer):
            pass

        ptr = Pointer("/a~1b")
        suffixes = [JsonPointer("/m~0n"), Pointer("/m~0n"),
                    OtherPointer("/m~0n"), "/m~0n", ["m~n"]]
        for suffix in suffixes:
            with self.subTest(suffix=suffix):
                joined = ptr.join(suffix)
                self.assertIs(type(joined), Pointer)
                self.assertEqual(joined.path, "/a~1b/m~0n")
        self.assertEqual(ptr.path, "/a~1b")

    def test_join_magic_subclass(self):
        class Pointer(JsonPointer):
            pass

        ptr = Pointer("/a") / JsonPointer("/b") / ["c"]
        self.assertIs(type(ptr), Pointer)
        self.assertEqual(ptr.path, "/a/b/c")


class WrongInputTests(unittest.TestCase):

    def test_no_start_slash(self):
        # an exception is raised when the pointer string does not start with /
        self.assertRaises(JsonPointerException, JsonPointer, 'some/thing')

    def test_invalid_index(self):
        # 'a' is not a valid list index
        doc = [0, 1, 2]
        self.assertRaises(JsonPointerException, resolve_pointer, doc, '/a')

    def test_oob(self):
        # this list does not have 10 members
        doc = [0, 1, 2]
        self.assertRaises(JsonPointerException, resolve_pointer, doc, '/10')

    def test_trailing_escape(self):
        self.assertRaises(JsonPointerException, JsonPointer, '/foo/bar~')

    def test_invalid_escape(self):
        self.assertRaises(JsonPointerException, JsonPointer, '/foo/bar~2')

    def test_leading_zero(self):
        doc = [0, 1, 2]
        self.assertRaises(JsonPointerException, resolve_pointer, doc, '/01')

    def test_string_not_indexable(self):
        doc = {"foo": "should-not-be-indexable"}
        self.assertRaises(JsonPointerException, resolve_pointer, doc, "/foo/0")

        ptr = JsonPointer("/foo/0")
        self.assertRaises(JsonPointerException, ptr.resolve, doc)


@unittest.skipUnless(hasattr(sys, 'get_int_max_str_digits'),
                     'Integer string conversion limits are not available')
class LargeIndexTests(unittest.TestCase):

    def setUp(self):
        limit = sys.get_int_max_str_digits()
        if not limit:
            self.skipTest('Integer string conversion limit is disabled')
        self.token = '1' * (limit + 1)
        self.pointer = '/' + self.token

    def test_resolve_large_index(self):
        self.assertRaises(JsonPointerException, resolve_pointer,
                          [0], self.pointer)

    def test_resolve_large_index_default(self):
        default = object()
        self.assertIs(resolve_pointer([0], self.pointer, default), default)
        self.assertIs(resolve_pointer({'items': [0]},
                                      '/items' + self.pointer, default),
                      default)

    def test_to_last_large_index(self):
        self.assertRaises(JsonPointerException,
                          JsonPointer(self.pointer).to_last, [0])

    def test_set_large_index(self):
        for inplace in (True, False):
            with self.subTest(inplace=inplace):
                doc = [0]
                self.assertRaises(JsonPointerException, set_pointer,
                                  doc, self.pointer, 1, inplace=inplace)
                self.assertEqual(doc, [0])

    def test_large_numeric_object_member(self):
        doc = {self.token: 'old'}
        self.assertEqual(resolve_pointer(doc, self.pointer), 'old')
        set_pointer(doc, self.pointer, 'new')
        self.assertEqual(doc, {self.token: 'new'})


class ToLastTests(unittest.TestCase):

    def test_empty_path(self):
        doc = {'a': [1, 2, 3]}
        ptr = JsonPointer('')
        last, nxt = ptr.to_last(doc)
        self.assertEqual(doc, last)
        self.assertTrue(nxt is None)

    def test_path(self):
        doc = {'a': [{'b': 1, 'c': 2}, 5]}
        ptr = JsonPointer('/a/0/b')
        last, nxt = ptr.to_last(doc)
        self.assertEqual(last, {'b': 1, 'c': 2})
        self.assertEqual(nxt, 'b')


class SetTests(unittest.TestCase):

    def test_set(self):
        doc = {
            "foo": ["bar", "baz"],
            "": 0,
            "a/b": 1,
            "c%d": 2,
            "e^f": 3,
            "g|h": 4,
            "i\\j": 5,
            "k\"l": 6,
            " ": 7,
            "m~n": 8
        }
        origdoc = copy.deepcopy(doc)

        # inplace=False
        newdoc = set_pointer(doc, "/foo/1", "cod", inplace=False)
        self.assertEqual(resolve_pointer(newdoc, "/foo/1"), "cod")

        self.assertEqual(len(doc["foo"]), 2)
        newdoc = set_pointer(doc, "/foo/-", "xyz", inplace=False)
        self.assertEqual(resolve_pointer(newdoc, "/foo/2"), "xyz")
        self.assertEqual(len(doc["foo"]), 2)
        self.assertEqual(len(newdoc["foo"]), 3)

        newdoc = set_pointer(doc, "/", 9, inplace=False)
        self.assertEqual(resolve_pointer(newdoc, "/"), 9)

        newdoc = set_pointer(doc, "/fud", {}, inplace=False)
        newdoc = set_pointer(newdoc, "/fud/gaw", [1, 2, 3], inplace=False)
        self.assertEqual(resolve_pointer(newdoc, "/fud"), {'gaw': [1, 2, 3]})

        newdoc = set_pointer(doc, "", 9, inplace=False)
        self.assertEqual(newdoc, 9)

        self.assertEqual(doc, origdoc)

        # inplace=True
        set_pointer(doc, "/foo/1", "cod")
        self.assertEqual(resolve_pointer(doc, "/foo/1"), "cod")

        self.assertEqual(len(doc["foo"]), 2)
        set_pointer(doc, "/foo/-", "xyz")
        self.assertEqual(resolve_pointer(doc, "/foo/2"), "xyz")
        self.assertEqual(len(doc["foo"]), 3)

        set_pointer(doc, "/", 9)
        self.assertEqual(resolve_pointer(doc, "/"), 9)

        self.assertRaises(JsonPointerException, set_pointer, doc, "/fud/gaw", 9)

        set_pointer(doc, "/fud", {})
        set_pointer(doc, "/fud/gaw", [1, 2, 3])
        self.assertEqual(resolve_pointer(doc, "/fud"), {'gaw': [1, 2, 3]})

        self.assertRaises(JsonPointerException, set_pointer, doc, "", 9)


class AltTypesTests(unittest.TestCase):
    class Node(object):
        def __init__(self, name, parent=None):
            self.name = name
            self.parent = parent
            self.left = None
            self.right = None

        def set_left(self, node):
            node.parent = self
            self.left = node

        def set_right(self, node):
            node.parent = self
            self.right = node

        def __getitem__(self, key):
            if key == 'left':
                return self.left
            if key == 'right':
                return self.right

            raise KeyError("Only left and right supported")

        def __setitem__(self, key, val):
            if key == 'left':
                return self.set_left(val)
            if key == 'right':
                return self.set_right(val)

            raise KeyError("Only left and right supported: %s" % key)

    class mdict(object):
        def __init__(self, d):
            self._d = d

        def __getitem__(self, item):
            return self._d[item]

    mdict = mdict({'root': {'1': {'2': '3'}}})
    Node = Node

    def test_alttypes(self):
        Node = self.Node

        root = Node('root')
        root.set_left(Node('a'))
        root.left.set_left(Node('aa'))
        root.left.set_right(Node('ab'))
        root.set_right(Node('b'))
        root.right.set_left(Node('ba'))
        root.right.set_right(Node('bb'))

        self.assertEqual(resolve_pointer(root, '/left').name, 'a')
        self.assertEqual(resolve_pointer(root, '/left/right').name, 'ab')
        self.assertEqual(resolve_pointer(root, '/right').name, 'b')
        self.assertEqual(resolve_pointer(root, '/right/left').name, 'ba')

        newroot = set_pointer(root, '/left/right', Node('AB'), inplace=False)
        self.assertEqual(resolve_pointer(root, '/left/right').name, 'ab')
        self.assertEqual(resolve_pointer(newroot, '/left/right').name, 'AB')

        set_pointer(root, '/left/right', Node('AB'))
        self.assertEqual(resolve_pointer(root, '/left/right').name, 'AB')

    def test_mock_dict_sanity(self):
        doc = self.mdict
        default = None

        # TODO: Generate this automatically for any given object
        path_to_expected_value = {
            '/root/1': {'2': '3'},
            '/root': {'1': {'2': '3'}},
            '/root/1/2': '3',
        }

        for path, expected_value in path_to_expected_value.items():
            self.assertEqual(resolve_pointer(doc, path, default), expected_value)

    def test_mock_dict_returns_default(self):
        doc = self.mdict
        default = None

        path_to_expected_value = {
            '/foo': default,
            '/x/y/z/d': default
        }

        for path, expected_value in path_to_expected_value.items():
            self.assertEqual(resolve_pointer(doc, path, default), expected_value)

    def test_mock_dict_raises_key_error(self):
        doc = self.mdict
        self.assertRaises(JsonPointerException, resolve_pointer, doc, '/foo')
        self.assertRaises(JsonPointerException, resolve_pointer, doc, '/root/1/2/3/4')


class CommandLineTests(unittest.TestCase):
    """ Tests the jsonpointer command line utility """

    ROOT = os.path.dirname(os.path.abspath(__file__))
    SCRIPT = os.path.join(ROOT, 'bin', 'jsonpointer')

    A_OUT = '[1, 2, 3]\n'
    B_OUT = '{"b": [1, 3, 4]}\n'

    def setUp(self):
        tmpdir = tempfile.TemporaryDirectory()
        self.addCleanup(tmpdir.cleanup)
        self.dir = tmpdir.name

        self._write('a.json', '{ "a": [1, 2, 3] }')
        self._write('b.json', '{ "a": {"b": [1, 3, 4]}, "b": 1 }')
        self._write('ptr.txt', '/a\n')

    def _write(self, name, content):
        with open(os.path.join(self.dir, name), 'w') as f:
            f.write(content)

    def _run(self, *args):
        env = dict(os.environ, PYTHONPATH=self.ROOT)
        return subprocess.run([sys.executable, self.SCRIPT] + list(args),
                              cwd=self.dir, env=env, capture_output=True,
                              text=True)

    def test_positional_pointer(self):
        proc = self._run('/a', 'a.json', 'b.json')
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(proc.stdout, self.A_OUT + self.B_OUT)

    def test_positional_pointer_single_file(self):
        proc = self._run('/a', 'a.json')
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(proc.stdout, self.A_OUT)

    def test_pointer_file(self):
        proc = self._run('-f', 'ptr.txt', 'a.json', 'b.json')
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(proc.stdout, self.A_OUT + self.B_OUT)

    # 2026-10-11: A pointer file's trailing spaces are part of its member name.
    def test_pointer_file_preserves_member_whitespace(self):
        self._write('space.json', '{"a ": "expected", "a": "wrong"}')
        for newline in ('', '\n', '\r\n'):
            with self.subTest(newline=newline):
                with open(os.path.join(self.dir, 'space.txt'), 'w', newline='') as f:
                    f.write('/a ' + newline)
                proc = self._run('-f', 'space.txt', 'space.json')
                self.assertEqual(proc.returncode, 0, proc.stderr)
                self.assertEqual(proc.stdout, '"expected"\n')

    def test_pointer_file_single_file(self):
        proc = self._run('-f', 'ptr.txt', 'a.json')
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(proc.stdout, self.A_OUT)

    def test_pointer_option(self):
        proc = self._run('-p', '/a', 'a.json', 'b.json')
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(proc.stdout, self.A_OUT + self.B_OUT)

    def test_no_pointer(self):
        proc = self._run('a.json')
        self.assertEqual(proc.returncode, 2)
        self.assertIn('a JSON pointer is required', proc.stderr)

    def test_missing_pointer_multiple_files(self):
        proc = self._run('a.json', 'b.json')
        self.assertEqual(proc.returncode, 2)
        self.assertIn("invalid JSON pointer 'a.json'", proc.stderr)
        self.assertEqual(proc.stdout, '')

    def test_invalid_pointer_file(self):
        self._write('bad.txt', 'a\n')
        proc = self._run('-f', 'bad.txt', 'a.json')
        self.assertEqual(proc.returncode, 2)
        self.assertIn("invalid JSON pointer 'a'", proc.stderr)

    def test_empty_pointer(self):
        proc = self._run('', 'a.json')
        self.assertEqual(proc.returncode, 0, proc.stderr)
        self.assertEqual(proc.stdout, '{"a": [1, 2, 3]}\n')

    def test_unresolvable_pointer(self):
        proc = self._run('/x', 'a.json')
        self.assertEqual(proc.returncode, 1)
        self.assertIn('Could not resolve pointer', proc.stderr)
        self.assertEqual(proc.stdout, '')

    def test_unresolvable_pointer_in_one_file(self):
        # /b resolves in b.json only; a.json is still reported but b.json
        # is processed
        proc = self._run('/b', 'a.json', 'b.json')
        self.assertEqual(proc.returncode, 1)
        self.assertIn('Could not resolve pointer', proc.stderr)
        self.assertEqual(proc.stdout, '1\n')

    def test_pointer_file_requires_value(self):
        proc = self._run('-f', '-p', '/a', 'a.json')
        self.assertEqual(proc.returncode, 2)
        self.assertIn('expected one argument', proc.stderr)

    def test_pointer_and_pointer_file_exclusive(self):
        proc = self._run('-p', '/a', '-f', 'ptr.txt', 'a.json')
        self.assertEqual(proc.returncode, 2)
        self.assertIn('not allowed with', proc.stderr)


class VerboseExceptionsTests(unittest.TestCase):

    def setUp(self):
        # Save original value and ensure verbose mode is on for each test
        self._original = jsonpointer.VERBOSE_EXCEPTIONS
        jsonpointer.VERBOSE_EXCEPTIONS = True

    def tearDown(self):
        jsonpointer.VERBOSE_EXCEPTIONS = self._original

    def test_verbose_exception_includes_doc(self):
        doc = {'foo': 1}
        try:
            resolve_pointer(doc, '/bar')
            self.fail('Expected JsonPointerException')
        except JsonPointerException as e:
            self.assertIn(repr(doc), str(e))

    def test_non_verbose_exception_excludes_doc(self):
        doc = {'foo': 1}
        jsonpointer.VERBOSE_EXCEPTIONS = False
        try:
            resolve_pointer(doc, '/bar')
            self.fail('Expected JsonPointerException')
        except JsonPointerException as e:
            self.assertNotIn(repr(doc), str(e))
            self.assertIn('bar', str(e))


def load_tests(loader, tests, ignore):
    tests.addTests(doctest.DocTestSuite(jsonpointer))
    return tests
